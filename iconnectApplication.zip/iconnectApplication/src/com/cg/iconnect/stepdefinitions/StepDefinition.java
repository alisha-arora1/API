package com.cg.iconnect.stepdefinitions;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.iconnect.beans.Clarity;
import com.cg.iconnect.beans.IConnect;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	private WebDriver driver;
	private IConnect iconnect;
	private Clarity clarity;

	@Before
	public void setUpStepEnv(){
		System.setProperty("webdriver.chrome.driver", "D:\\New folder\\chromedriver.exe");
	}


	@Given("^User is on iconnect HomePage$")
	public void user_is_on_iconnect_HomePage() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://iconnect.fs.capgemini.com/");
		iconnect=PageFactory.initElements(driver,IConnect.class);
	}

	@When("^User clicks on clarity icon$")
	public void user_clicks_on_clarity_icon() throws Throwable {
		iconnect.click();
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		//driver.switchTo().window(tabs2.get(0));

	}

	@Then("^clarity login plage is displayed$")
	public void clarity_login_plage_is_displayed() throws Throwable {
		System.out.println(driver.getTitle());
		driver.close();

	}

	@Given("^User is on clarity login page$")
	public void user_is_on_clarity_login_page() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://clarity.fs.capgemini.com/");
		clarity=PageFactory.initElements(driver,Clarity.class);
		Thread.sleep(2000);
	}

	@When("^User enters username and password$")
	public void user_enters_username_and_password() throws Throwable {
		clarity.setUsername("gkravani");
		clarity.setPassword("Kr@vani116");
	}

	@Then("^Clarity PPM page is displayed$")
	public void clarity_PPM_page_is_displayed() throws Throwable {
		clarity.clikSignIn();
		
	}
	@When("^User enters invalid username and password$")
	public void user_enters_invalid_username_and_password() throws Throwable {
		clarity.setUsername("gkra");
		clarity.setPassword("Kr@vani16");
	}

	@Then("^error page is displayed$")
	public void error_page_is_displayed() throws Throwable {
	   
	}



}
