package com.cg.com.cg.testng;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestNG {

	public WebDriver driver;
	
	@BeforeClass
	public void setUpStepEnv(){
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\alokapur\\Downloads\\chromedriver.exe");
	}

  @Test

  public void main() {

	// Find the element that's ID attribute is 'account'(My Account)
	  driver.findElement(By.name("q")).click();
    driver.findElement(By.name("q")).sendKeys("arshad");
     driver.findElement(By.xpath("//*[@id='tsf']/div[2]/div/div[3]/center/input[1]")).submit();
     

  }

  @BeforeMethod

  public void beforeMethod() {

	  // Create a new instance of the Firefox driver

      driver = new ChromeDriver();

      //Put a Implicit wait, this means that any search for elements on the page could take the time the implicit wait is set for before throwing exception

      //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

      //Launch the Online Store Website

      driver.get("https://www.google.com");

  }

  @AfterMethod

  public void afterMethod() {

	  // Close the driver

 //     driver.quit();

  }

}