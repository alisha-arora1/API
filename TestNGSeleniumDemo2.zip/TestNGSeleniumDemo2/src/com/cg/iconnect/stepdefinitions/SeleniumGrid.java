package com.cg.iconnect.stepdefinitions;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.iconnect.beans.IConnect;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class SeleniumGrid {

	static WebDriver driver;
	static String nodeUrl;
	static IConnect iconnect;
	
	
	@Before
	public static void grid() {
		
		try {
			nodeUrl="http://10.102.100.214:4290/wd/hub";
			DesiredCapabilities capabilities= DesiredCapabilities.chrome();
			capabilities.setBrowserName("chrome");
			capabilities.setPlatform(Platform.WINDOWS);
			driver = new RemoteWebDriver(new URL(nodeUrl), capabilities);
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(45, TimeUnit.SECONDS);
			driver.get("https://selfportal.capgemini.com");
		//	driver.get("http://www.google.co.in/");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		
		
		

	}
	
	
	@Given("^User is on safenet portal$")
	public void user_is_on_safenet_portal() throws Throwable {
		
		
		
		iconnect = new IConnect();
		PageFactory.initElements(driver, iconnect);
	}

	@When("^User clicks enters username and password$")
	public void user_clicks_enters_username_and_password() throws Throwable {
		iconnect.setUsername("mkouchik");
		iconnect.setPassword("Megha@123#");
		iconnect.clickLogin();
	}

	@When("^clicks submit$")
	public void clicks_submit() throws Throwable {
		driver.get("https://iconnect.fs.capgemini.com/");
	}

	@Then("^User should be on IConnect Page$")
	public void user_should_be_on_IConnect_Page() throws Throwable {
		Assert.assertEquals("Employee Self Service", driver.getTitle());
	}
	
	@When("^user clicks on lms icon$")
	public void user_clicks_on_lms_icon() throws Throwable {
	    IConnect.lms(driver).click();
	    Set<String> allWindows = driver.getWindowHandles();
		ArrayList<String> tabs = new ArrayList<String>(allWindows);
		driver.switchTo().window(tabs.get(1));
	}

	@Then("^open lms portal$")
	public void open_lms_portal() throws Throwable {
	    Assert.assertEquals("Leave Management System", driver.getTitle());
	}
	
	@When("^user clicks on apply leave$")
	public void user_clicks_on_apply_leave() throws Throwable {
	    iconnect.clickManageLeave();
	    iconnect.clickApplyLeave();
	}

	@Then("^open apply leave page$")
	public void open_apply_leave_page() throws Throwable {
	    Assert.assertEquals("https://lms.in.capgemini.com/ApplyLeave/ApplyLeave", driver.getCurrentUrl());
	}
	
	@When("^user clicks submit without entering anything$")
	public void user_clicks_submit_without_entering_anything() throws Throwable {
	    Thread.sleep(20000);
		iconnect.applyLeaveSubmit();
	}

	@Then("^it needs to display Enter Start Date$")
	public void it_needs_to_display_Enter_Start_Date() throws Throwable {
	    Assert.assertEquals("Select Start Date", IConnect.errorStartDate(driver).getText());
	}

}
